<?
$libPath = 'lib';
$musicRootDirAddr = "music";
?>

<html>
<head>
<title>song_exchange</title>
<style>
    @import url('style.css');
    body {
        font-size: .8em;
        font-family: monospace;
    }
    .object {

    }
    .lbl {
        float: left;
        display: block;
        width: 300px;
        border: 1px dotted black;
        border-right: 0;
    }
</style>

</head>
<body>

<h2><a href='index.php'>home</h2>

<?php


require_once("$libPath/monolithNmetagone/functions.php");




/* config */
$musicDir = isset($_GET['music_dir']) ? $_GET['music_dir'] : 'music/'; // this is path relative to server
// e("musicDir: ". $musicDir);

$files = listMp3($musicDir);


$dirs = listDirs($musicDir ."/"); // must be slash-final
// pr($dirs);
foreach ($dirs as $file) {
    e("<a href='". $_SERVER['PHP_SELF'] ."?music_dir=$musicDir$file/'>$file</a><br />");
}
e('<hr />');

if ($files!=array()) {
    foreach ($files as $file) {
        $playlistAddrTmp = "playlist/$musicDir/$file";
        // $playlistAddrTmp = str_replace(" ", "%20", $playlistAddrTmp);
        ?>
        <div class='object'><span class='lbl'><a href='<?=$musicDir . $file;?>'><?=$musicDir . $file;?></a></span>
            <object type="application/x-shockwave-flash" width="400" height="60"
    data="lib/xspf/xspf_player_slim.swf?playlist_url=playlist/<?=$musicDir;?>/<?=$file;?>">
    <param name="movie"
    value="lib/xspf/xspf_player_slim.swf?playlist_url=playlist/<?=$musicDir;?>/<?=$file;?>" />
    </object>
        </div>
        <!-- <a href='lib/xspf/xspf_player_slim.swf?playlist_url=playlist/<?=$musicDir;?>/<?=$file;?>'>lib/xspf/xspf_player_slim.swf?playlist_url=playlist/<?=$musicDir;?>/<?=$file;?></a> -->
        <?php
    }
}

?>

<!--
<object type="application/x-shockwave-flash" width="400" height="170"
data="http://localhost/manydemons2/song_exchange/lib/xspf/xspf_player_slim.swf?playlist_url=http://localhost/manydemons2/song_exchange/playlist/localhost/manydemons2/song_exchange/music/a1981.mp3">
<param name="movie"
value="http://localhost/manydemons2/song_exchange/lib/xspf/xspf_player_slim.swf?playlist_url=http://localhost/manydemons2/song_exchange/playlist/localhost/manydemons2/song_exchange/music/a1981.mp3" />
</object>
-->

<!--
<object type="application/x-shockwave-flash" width="400" height="170"
data="http://localhost/manydemons2/song_exchange/lib/xspf/xspf_player_slim.swf?playlist_url=http://localhost/manydemons2/song_exchange/playlist/localhost/manydemons2/song_exchange/music/a1981.mp3">
<param name="movie"
value="http://localhost/manydemons2/song_exchange/lib/xspf/xspf_player_slim.swf?playlist_url=http://localhost/manydemons2/song_exchange/playlist/localhost/manydemons2/song_exchange/music/a1981.mp3" />
</object>
-->







